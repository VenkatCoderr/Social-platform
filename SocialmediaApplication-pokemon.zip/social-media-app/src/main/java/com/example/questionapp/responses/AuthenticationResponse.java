package com.example.questionapp.responses;

import lombok.Data;

@Data
public class AuthenticationResponse {

    String message;
    Long userId;
    String refreshToken;
    String AccessToken;
    
    public AuthenticationResponse() {
		
	}
    
	public AuthenticationResponse(String message, Long userId, String refreshToken, String accessToken) {
		super();
		this.message = message;
		this.userId = userId;
		this.refreshToken = refreshToken;
		AccessToken = accessToken;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getRefreshToken() {
		return refreshToken;
	}
	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}
	public String getAccessToken() {
		return AccessToken;
	}
	public void setAccessToken(String accessToken) {
		AccessToken = accessToken;
	}


}

