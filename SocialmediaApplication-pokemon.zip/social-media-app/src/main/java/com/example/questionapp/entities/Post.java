package com.example.questionapp.entities;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.util.Date;

@Entity
@Data
@Table(name = "post")
public class Post {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)             //This part of the annotation indicates a many-to-one relationship between two entities
    @JoinColumn(name="user_id",nullable = false)    // This column must always have a value (it cannot be null), ensuring that every post is associated with a specific user.
    @OnDelete(action = OnDeleteAction.CASCADE)  
    private User user;

    private String title;

    @Lob                                   //The @Lob annotation is used to map an entity field to a database column that can hold large data, such as large text strings or binary files.
    @Column(columnDefinition = "text")
    private String text;

    @Temporal(TemporalType.TIMESTAMP)   /*//You use @Temporal(TemporalType.TIMESTAMP) when you need to know exactly when something happened, 
                                        //not just the day, but also the time down to the second.*/
    private Date createDate;
    
    
    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	


}
