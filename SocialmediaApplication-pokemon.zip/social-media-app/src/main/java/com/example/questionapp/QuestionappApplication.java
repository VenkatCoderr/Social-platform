package com.example.questionapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuestionappApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuestionappApplication.class, args);
	}

}
