package com.example.questionapp.requests;

import lombok.Data;

@Data
public class RefreshTokenRequest {

	
     private Long userId;
    
    private String refreshToken;
    
    public RefreshTokenRequest(Long userId, String refreshToken) {
		super();
		this.userId = userId;
		this.refreshToken = refreshToken;
	}
    public RefreshTokenRequest() {
	
	}
    public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getRefreshToken() {
		return refreshToken;
	}
	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}
}
