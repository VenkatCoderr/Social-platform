package com.example.questionapp.requests;

import lombok.Data;

@Data
public class UpdateCommentRequest {
	
	private String text;

	public UpdateCommentRequest() {
		
	}
	public UpdateCommentRequest(String text) {
		super();
		this.text = text;
	}
	
    public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

}
