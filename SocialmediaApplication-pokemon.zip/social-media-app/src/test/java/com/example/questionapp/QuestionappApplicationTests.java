package com.example.questionapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuestionappApplicationTests {

	@Test
	void contextLoads() {
	}

}
